import java.time.LocalDateTime;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class GameTest {

    public static LocalDateTime oldDate = LocalDateTime.now();

    public void play(int width, int height, int numberOfPlayer, int privateZone, long moveInterval, long timout) {
        Field field = new Field(width, height, numberOfPlayer, privateZone, moveInterval, timout);
        Thread thread = new Thread(field, "field");
        thread.start();
}
    @Test
    public void testGame() {
        GameTest game = new GameTest();
        try {
            game.play(30, 30, 10, 2, 10, 100);
        } catch (Exception ex) {
            System.out.println("Error in game" + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        GameTest game = new GameTest();
        try {
            game.play(30, 30, 10, 2, 10, 100);
        } catch (Exception ex) {
            System.out.println("Error in game" + ex.getMessage());
        }
    }

}